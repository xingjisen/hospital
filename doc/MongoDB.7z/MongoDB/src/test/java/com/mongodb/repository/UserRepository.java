package com.mongodb.repository;

import com.mongodb.User;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

/**
 * @author Jason
 * @PACKAGE_NAME com.mongodb.repository
 * @Description
 * @date 2024-09-19 17:07
 */
@Repository
public interface UserRepository extends MongoRepository<User, String> {
}
