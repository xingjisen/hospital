package com.mongodb.repository;

import com.mongodb.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.util.Arrays;


@SpringBootTest
class MongoDbRepositoryTests {
    @Autowired
    private UserRepository userRepository;

    @Test
    void insTest() {
        User user = new User();
        user.setName("11邢继森11");
        user.setAge(181);
        user.setEmail("aaa.bbb@aa.com");
//        user.setCreateData(new Calendar().getTime());
        User insert = userRepository.insert(user);
        System.out.println(insert);
    }

    @Test
    void findAllTest() {
        for (User user : userRepository.findAll()) {
            System.out.println(user);
        }
    }

    @Test
    void findByIdTest() {
//        User byId = userRepository.findById("66ebd82c9411000092000a53").get();
        User byId = userRepository.findById("66ebd82c9411000092000a531").orElse(null);
        System.out.println(byId);
    }

    @Test
    void findTest() {
        User user = new User();
        user.setName("11邢继森11");

        Example<User> userExample = Example.of(user);
        for (User u : userRepository.findAll(userExample)) {
            System.out.println(u);
        }
    }

    @Test
    void findLikeTest() {
        // 设置模糊查询匹配规则
        ExampleMatcher matcher = ExampleMatcher.matching()
                .withStringMatcher(ExampleMatcher.StringMatcher.CONTAINING)
                .withIgnoreCase(true);
        User user = new User();
        user.setName("森");

        Example<User> userExample = Example.of(user, matcher);
        for (User u : userRepository.findAll(userExample)) {
            System.out.println(u);
        }

    }

    @Test
    void findPageTest() {
        // 0代表第一页
        Pageable pageable = PageRequest.of(2, 3);
        // 设置模糊查询匹配规则
        ExampleMatcher matcher = ExampleMatcher.matching()
                .withStringMatcher(ExampleMatcher.StringMatcher.CONTAINING)
                .withIgnoreCase(true);

        User user = new User();
        user.setName("11邢继森11");

        Example<User> userExample = Example.of(user);
        for (User u : userRepository.findAll(userExample, pageable)) {
            System.out.println(u);
        }
    }

    @Test
    void updateTest() {
        User user = userRepository.findById("66ebf1269411000092000a56").orElse(null);
        user.setAge(user.getAge() + 10);
        User save = userRepository.save(user);
        System.out.println(save);
    }

    @Test
    void delTest() {
        userRepository.deleteById("66ea7bd3225700002f001eac");
    }

    @Test
    void saveAllTest() {
        User a = new User("a", 1);
        User b = new User("b", 2);
        User c = new User("c", 3);
        User d = new User("d", 4);
        userRepository.saveAll(Arrays.asList(a, b, c, d));
    }

}
