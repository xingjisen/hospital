package com.mongodb;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

/**
 * @author Jason
 * @PACKAGE_NAME com.mongodb
 * @Description
 * @date 2024-09-19 15:40
 */
@Data
@Document("user")
@NoArgsConstructor
public class User {
    @Id
    private String id;
    private String name;
    private Integer age;
    private Boolean sex;
    private String email;
    private Date createData;

    public User(String name, Integer age) {
        this.name = name;
        this.age = age;
    }
}
