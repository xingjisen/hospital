package com.mongodb;

import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.UpdateResult;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import java.util.List;
import java.util.regex.Pattern;


@SpringBootTest
class MongoDbApplicationTests {
    @Autowired
    private MongoTemplate mongoTemplate;

    @Test
    void insTest() {
        User user = new User();
        user.setName("邢继森");
        user.setAge(18);
        user.setEmail("aaa.bbb@aa.com");
//        user.setCreateData(new Calendar().getTime());
        User insert = mongoTemplate.insert(user);
        System.out.println(insert);
    }

    @Test
    void findAllTest() {
        for (User user : mongoTemplate.findAll(User.class)) {
            System.out.println(user);
        }
    }

    @Test
    void findByIdTest() {
        User byId = mongoTemplate.findById("66ebd6c7fcc75e01069b81f4", User.class);
        System.out.println(byId);
    }

    @Test
    void findTest() {
        Query query = new Query(
                Criteria.where("name").is("邢继森")
                        .and("age").is(18)
        );
        for (User user : mongoTemplate.find(query, User.class)) {
            System.out.println(user);
        }
    }

    @Test
    void findLikeTest() {
        String name = "继";
        String regex = String.format("%s%s%s", "^.*", name, ".*$");
        Pattern pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
        Query query = new Query(
                Criteria.where("name").regex(pattern)
        );
        for (User user : mongoTemplate.find(query, User.class)) {
            System.out.println(user);
        }
    }

    @Test
    void findPageTest() {
        Integer pageNum = 2;
        Integer pageSize = 2;
        Query query = new Query();
        long count = mongoTemplate.count(query, User.class);
        System.out.println(count);
        List<User> users = mongoTemplate.find(query.skip((pageNum - 1) * pageSize).limit(pageSize), User.class);
        for (User user : users) {
            System.out.println(user);
        }
    }

    @Test
    void updateTest() {
        User user = mongoTemplate.findById("66ebd6c7fcc75e01069b81f4", User.class);
        user.setName("123456邢继森");
        Query query = new Query(Criteria.where("_id").is(user.getId()));
        Update update = new Update();
        update.set("name", user.getName());
        UpdateResult upsert = mongoTemplate.upsert(query, update, User.class);
        System.out.println(upsert);
    }

    @Test
    void updateTest1() {
        User user = mongoTemplate.findById("66ebd6c7fcc75e01069b81f4", User.class);
        user.setName("00000000");
        User upsert = mongoTemplate.save(user);
        System.out.println(upsert);
    }

    @Test
    void delTest() {
        Query query = new Query(Criteria.where("_id").is("66ebe84a9411000092000a54"));
        DeleteResult del = mongoTemplate.remove(query, User.class);
        System.out.println(del.getDeletedCount());
    }


}
