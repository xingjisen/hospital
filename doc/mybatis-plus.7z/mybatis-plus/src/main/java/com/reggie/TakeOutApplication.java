package com.reggie;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Jason
 * @PACKAGE_NAME com.reggie
 * @Description 启动类
 * @date 2024-08-31 11:07
 */
@Slf4j
@SpringBootApplication
public class TakeOutApplication {
    public static void main(String[] args) {
        SpringApplication.run(TakeOutApplication.class, args);
        log.info("项目启动成功!🎆( ´･･)ﾉ(._.`)🎉");
    }
}
