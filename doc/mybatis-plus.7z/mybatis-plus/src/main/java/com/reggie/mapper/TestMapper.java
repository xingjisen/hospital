package com.reggie.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.reggie.domain.Test;
import org.springframework.stereotype.Repository;

/**
 * @author Jason
 * @PACKAGE_NAME com.reggie.mapper
 * @Description
 * @date 2024-08-31 14:06
 */
@Repository
public interface TestMapper extends BaseMapper<Test> {
}
