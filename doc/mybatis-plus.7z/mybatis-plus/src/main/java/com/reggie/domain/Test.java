package com.reggie.domain;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.util.Date;

/**
 * @author Jason
 * @PACKAGE_NAME com.reggie.domain
 * @Description
 * @date 2024-08-31 14:05
 */
@Data
@TableName("test")
public class Test {
    @TableId(type = IdType.ID_WORKER_STR)
    private String id;

    private String name;
    private String age;
    private String sex;

    // 何时设置值
    @TableField(fill = FieldFill.INSERT)
    private Date createTime;
    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Date updateTime;

    // 乐观锁配置字段
    @Version
    @TableField(fill = FieldFill.INSERT)
    private Integer version;

    // 逻辑删除配置字段
    @TableLogic
    @TableField(fill = FieldFill.INSERT)
    private Integer deleted;
}
