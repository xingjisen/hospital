package com.reggie;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.reggie.mapper.TestMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Jason
 * @PACKAGE_NAME PACKAGE_NAME
 * @Description
 * @date 2024-08-31 14:09
 */
@SpringBootTest
public class TestApplication {

    @Autowired
    TestMapper mapper;

    @Test
    public void testList() {
        List<com.reggie.domain.Test> tests = mapper.selectList(null);
        System.out.println(tests);
    }

    @Test
    public void testPut() {
        com.reggie.domain.Test test = new com.reggie.domain.Test();
        test.setId("1830161634104893441");
        test.setName("00000");
        test.setAge("00000");
        test.setSex("男00000");
        int i = mapper.updateById(test);
        System.out.println(i);
    }

    @Test
    public void testAdd() {
        com.reggie.domain.Test test = new com.reggie.domain.Test();
        test.setName("aaa");
        test.setAge("20");
        test.setSex("男");
        int insert = mapper.insert(test);
        System.out.println(insert);
    }

    @Test
    public void testDel() {
        int i = mapper.deleteById("1830181793326604290");
        System.out.println(i);
    }

    @Test
    public void testOptimisticLocker() {
        // 根据ID查询
        com.reggie.domain.Test test = mapper.selectById("1830179492683776001");
        test.setName("邢继森");
        // 修改
        mapper.updateById(test);
    }


    /**
     * 多种查询
     */
    // 多个ID批量查询
    @Test
    public void testSelectIds() {
        List<com.reggie.domain.Test> tests = mapper.selectBatchIds(Arrays.asList(1, 2, 3, 4, 5, 6, 8));
        System.out.println(tests);
    }

    // 简单的条件查询
    @Test
    public void testSelectMap() {
        Map<String, Object> objectObjectHashMap = new HashMap<>();
        objectObjectHashMap.put("name", "aaa");
        objectObjectHashMap.put("age", "20");
        List<com.reggie.domain.Test> tests = mapper.selectByMap(objectObjectHashMap);
        System.out.println(tests);
    }

    //分页查询
    @Test
    public void testSelectPage() {
        Page<com.reggie.domain.Test> page = new Page(1, 3);
        IPage<com.reggie.domain.Test> testIPage = mapper.selectPage(page, null);

        System.out.println("数据集合: " + testIPage.getRecords());
        System.out.println("页码: " + testIPage.getPages());
        System.out.println("当前页: " + testIPage.getCurrent());
        System.out.println("总记录数: " + testIPage.getTotal());
        System.out.println("-----: " + testIPage.getSize());
    }


    /**
     * 多种删除
     */

    // 根据id删除
    @Test
    public void testDelId() {
        mapper.deleteById("8");
    }

    // 批量根据Id删除
    @Test
    public void testDelIds() {
        int i = mapper.deleteBatchIds(Arrays.asList(1, 2, 3, 4, 5));
        System.out.println(i);
    }

    @Test
    public void testDelMap() {
        Map<String, Object> objectObjectHashMap = new HashMap<>();
        objectObjectHashMap.put("name", "aaa");
        objectObjectHashMap.put("age", "20");
        mapper.deleteByMap(objectObjectHashMap);
    }

    // 逻辑删除
    @Test
    public void testDelLogic() {

    }


    // 复杂条件查询
    @Test
    public void testDelComplicatedCondition() {
        QueryWrapper<com.reggie.domain.Test> testQueryWrapper = new QueryWrapper<>();
        testQueryWrapper.ge("age", "22");
        List<Map<String, Object>> maps = mapper.selectMaps(testQueryWrapper);
        System.out.println(maps);
        /**
         * ge           大于等于
         * gt           小于等于
         * le           大于
         * lt           小于
         * eq           等于
         * ne           不等于
         * betweeb      在区间范围
         * notBetween   不在区间范围
         * like         % * %
         * notLike
         * likeLeft     % *
         * likeRight    * %
         *
         * 排序
         * orderBy
         * orderByDesc
         * orderByAsc
         */

    }
}
